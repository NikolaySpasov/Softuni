﻿namespace TrafficLights.Enums
{
    public enum LightColor
    {
        Red,
        Green,
        Yellow
    }
}