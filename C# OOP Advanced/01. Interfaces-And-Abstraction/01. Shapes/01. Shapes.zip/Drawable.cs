﻿
interface IDrawable
{

    void Draw();
}


