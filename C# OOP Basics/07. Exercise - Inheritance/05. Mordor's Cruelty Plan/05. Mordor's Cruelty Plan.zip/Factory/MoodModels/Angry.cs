﻿namespace p05_MordorsCrueltyPlan.Factory.MoodModels
{
    public class Angry : Mood
    {
        public Angry() : base("Angry")
        {
        }
    }
}