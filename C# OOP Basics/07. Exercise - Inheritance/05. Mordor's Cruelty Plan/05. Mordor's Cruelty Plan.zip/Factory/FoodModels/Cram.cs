﻿namespace p05_MordorsCrueltyPlan.Factory.FoodModels
{
    public class Cram : Food
    {
        public Cram() : base(2)
        {
        }
    }
}