﻿namespace p05_MordorsCrueltyPlan.Factory.FoodModels
{
    public class Mushroom : Food
    {
        public Mushroom() : base(-10)
        {

        }
    }
}