﻿namespace p05_MordorsCrueltyPlan.Factory.FoodModels
{
    public class HoneyCake : Food
    {
        public HoneyCake() : base(5)
        {
        }
    }
}