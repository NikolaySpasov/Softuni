﻿namespace p05_MordorsCrueltyPlan.Factory.FoodModels
{
    public class Melon : Food
    {
        public Melon() : base(1)
        {
        }
    }
}