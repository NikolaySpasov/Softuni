﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.Stack_of_Strings
{
    class StartUp
    {
        static void Main(string[] args)
        {
        }
    }
}
