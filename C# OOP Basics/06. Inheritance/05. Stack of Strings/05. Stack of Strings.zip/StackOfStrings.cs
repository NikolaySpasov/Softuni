﻿
using System.Collections.Generic;
using System.Linq;

class StackOfStrings
{
    private List<string> data;

    public void Push(string element) 
    {

    }

    public string Pop()
    {

        return "";
    }

    public string Peek()
    {
        
        return "";
    }

    public bool IsEmpty()
    {
        return true;
    }

}

