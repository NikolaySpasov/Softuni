﻿
public abstract class TypeOfWorker
{

    private string id;

    protected TypeOfWorker(string id)
    {
        this.Id = id;
    }

    public string Id { get; set; }
}

