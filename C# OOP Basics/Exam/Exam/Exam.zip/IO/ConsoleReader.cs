﻿using System;

class ConsoleReader
{
    public string ReadLine()
    {
        return Console.ReadLine();
    }
}