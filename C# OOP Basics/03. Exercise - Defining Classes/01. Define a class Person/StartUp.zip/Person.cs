﻿using System;
using System.Reflection;




public class Person
{
    public string name;
    public int age;
}