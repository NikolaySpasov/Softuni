﻿namespace BashSoft
{
    public class Launcher
    {
        static void Main()
        {
            InputReader.StartReadingCommands();
        }
    }
}
