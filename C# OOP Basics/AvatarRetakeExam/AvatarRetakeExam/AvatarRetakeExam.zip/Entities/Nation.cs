﻿
using System.Collections.Generic;

public class Nation
{
    private List<Bender> benders;

    public Nation()
    {
        this.benders = new List<Bender>();
    }

}

