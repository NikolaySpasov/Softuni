﻿
public class NationBuilder
{
    void AssignBender(List<string> benderArgs)
    {
        //TODO: Add some logic here … 
        return ;
    }
    void AssignMonument(List<string> monumentArgs)
    {
        //TODO: Add some logic here … 
        return ;
    }
    string GetStatus(string nationsType)
    {
        //TODO: Add some logic here … 
        return "";
    }
    void IssueWar(string nationsType)
    {
        //TODO: Add some logic here … 
    }
    string GetWarsRecord()
    {
        //TODO: Add some logic here … 
        return "";
    }

}

